"""Training and evaluation helpers."""

